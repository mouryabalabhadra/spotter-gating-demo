export {};
//# sourceMappingURL=embedConfig.spec.d.ts.map