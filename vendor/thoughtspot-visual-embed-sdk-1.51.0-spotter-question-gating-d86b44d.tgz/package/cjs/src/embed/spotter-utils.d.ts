import { DefaultAppInitData } from '../types';
import type { SpotterQuotaConfig } from '../types';
import type { SpotterSidebarViewConfig, SpotterShareConversationConfig } from './conversation';
import type { VisualizationOverrides } from '../types';
/**
 * Resolves enablePastConversationsSidebar with
 * spotterSidebarConfig taking precedence over the
 * standalone flag.
 */
export declare const resolveEnablePastConversationsSidebar: (params: {
    spotterSidebarConfigValue?: boolean;
    standaloneValue?: boolean;
}) => boolean | undefined;
export declare function buildSpotterSidebarAppInitData<T extends DefaultAppInitData>(defaultAppInitData: T, viewConfig: {
    spotterSidebarConfig?: SpotterSidebarViewConfig;
    enablePastConversationsSidebar?: boolean;
    visualOverrides?: VisualizationOverrides;
}, handleError: (err: any) => void): T & {
    embedParams?: {
        spotterSidebarConfig?: SpotterSidebarViewConfig;
        visualOverridesParams?: VisualizationOverrides | null;
    };
};
export declare function buildSpotterShareConversationAppInitData<T extends DefaultAppInitData>(initData: T, viewConfig: {
    spotterShareConversationConfig?: SpotterShareConversationConfig;
}): T & {
    embedParams?: {
        spotterShareConversationConfig?: SpotterShareConversationConfig;
    };
};
/**
 * The flattened per-group allowance the embedded app reads from
 * `embedParams.spotterUsageLimits`.
 * @internal
 */
export interface SpotterUsageLimitEmbedParams {
    groupId: string;
    enabled?: boolean;
    usageLimit?: number;
    almostReachedThreshold?: number;
    upgradePlanUrl?: string;
}
/**
 * The quota payload handed to the embedded app.
 * @internal
 */
export interface SpotterQuotaEmbedParams {
    spotterQuota: SpotterQuotaConfig;
    noOfAllowedMessages?: number;
    almostReachedThreshold?: number;
    spotterUsageMonthlyReset?: boolean;
    spotterUsageLimits?: SpotterUsageLimitEmbedParams[];
    gatedSpotterContent?: string;
}
/**
 * Translates the public {@link SpotterQuotaConfig} into the flat
 * `embedParams` keys the embedded Spotter app consumes.
 *
 * Kept as a pure function so the mapping — which is the contract between the
 * SDK's public API and the app's internal param names — is unit-testable
 * without constructing an embed.
 * @internal
 */
export declare const mapSpotterQuotaToEmbedParams: (quota: SpotterQuotaConfig) => SpotterQuotaEmbedParams;
/**
 * Extends the APP_INIT payload with the resolved question-gating params.
 *
 * A quota that is absent or explicitly disabled contributes nothing to the
 * payload, so an embed without gating is byte-for-byte unchanged.
 */
export declare function buildSpotterQuotaAppInitData<T extends DefaultAppInitData>(initData: T, viewConfig: {
    spotterQuota?: SpotterQuotaConfig;
}): T & {
    embedParams?: SpotterQuotaEmbedParams;
};
//# sourceMappingURL=spotter-utils.d.ts.map