export {};
//# sourceMappingURL=sessionInfoService.spec.d.ts.map